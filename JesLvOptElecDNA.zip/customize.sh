#!/sbin/sh
SKIPUNZIP=0
AUTOMOUNT=true