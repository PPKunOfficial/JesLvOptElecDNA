#!/system/bin/sh
#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}
echo `cat $MODDIR/res/ElecDNA_desc` > /cache/ElecDNA.log 2>&1 &
# 该脚本将在设备开机后作为延迟服务启动
exit
COMP JESUSGO O3 POLLY TLTO
# JESUS GO
LOAD CPPStartPoint,KTStartPoint
POT res
DEP CRYTO,DATA,KTO STRPOT
SRT FUN ATOPC
FIND HKP
SET HKP HKP
ATCG HKP HKPT
ATOP HKPT
SET HKPT HKP
HCP HKP HKP
RT0
END FUN ATOPC 
ORR POT ATOPC 
POT 
SRT ATOPT,SDNA,P2PDN,RMCT,OPHW,RCKL
FCK OKL,OD,RECS